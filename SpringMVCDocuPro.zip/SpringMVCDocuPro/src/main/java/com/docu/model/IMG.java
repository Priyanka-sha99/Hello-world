package com.docu.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table
public class IMG {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column
	int imgId;
	
	@Column(name="img", columnDefinition="longblob")
	byte[] img1;
	
	
	
	
	@ManyToOne
	DocIMG d;
	
	
	
	public int getImgId() {
		return imgId;
	}

	public void setImgId(int imgId) {
		this.imgId = imgId;
	}

	public byte[] getImg1() {
		return img1;
	}

	public void setImg1(byte[] img1) {
		this.img1 = img1;
	}

	public DocIMG getD() {
		return d;
	}

	public void setD(DocIMG d) {
		this.d = d;
	}

	

	
	
	
}
