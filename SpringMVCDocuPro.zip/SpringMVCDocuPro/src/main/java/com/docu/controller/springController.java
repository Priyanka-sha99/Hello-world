package com.docu.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.mail.Session;
import javax.servlet.ServletException;
import javax.servlet.annotation.HttpConstraint;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.docu.mail.SendMail;
import com.docu.model.Address;
import com.docu.model.DocIMG;
import com.docu.model.DocuCost;
import com.docu.model.IMG;
import com.docu.model.User;
import com.docu.model.recordSenderRec;
import com.docu.services.docuServicesIntrf;

@Controller
public class springController {
@Autowired
docuServicesIntrf docuSrv;

@RequestMapping("/userLoginServ")
public ModelAndView userFirstLogin(@ModelAttribute("User") User u,HttpSession session)
{
	int f=0;
	System.out.println("Name: "+u.getName());
	f=docuSrv.checkUser(u);
	System.out.println(f);
	ModelAndView mv = new ModelAndView();
	//mv.addObject("dd", dd);
	if(f==1)
	{
		mv.setViewName("afterLoginToBoth");
		session.setAttribute("uname", u.getName());
	}
	else
		mv.setViewName("login");
	return mv;
}

@RequestMapping("/getStatus/{uname}")
public ModelAndView senderStatus(@PathVariable("uname") String uname)
{
	ModelAndView mv = new ModelAndView();
	User ur = docuSrv.getReceiveremail(uname);
	recordSenderRec rec= docuSrv.getStatusForSender(ur);
	List<Object> urc = new ArrayList<Object>();
	urc.add(ur);
	urc.add(rec);
	if(rec!=null)
	{
		//User u = docuSrv.getReceiverID(rec);
		mv.addObject("u", urc);
		mv.setViewName("statusInfoSender");
	}
	else
		mv.setViewName("login");
	return mv;
}

@RequestMapping("/getReqDatestatus/{uid}")
public ModelAndView getReqDatestatus(@PathVariable("uid") int uid)
{
	System.out.println("User id: "+uid);
	recordSenderRec rc = docuSrv.getrecordDetails(uid);
	ModelAndView mv = new ModelAndView();
	mv.addObject("rc", rc);
	mv.setViewName("statusInfoSender");
	
	return mv;
}

@RequestMapping("/userDocImgServ/{uname}")
public ModelAndView usertoStoreDocImgServ(@ModelAttribute("DocIMG") DocIMG di,@PathVariable("uname") String uname,HttpServletRequest request,@RequestParam("orgg") MultipartFile orgg, @RequestParam("front") MultipartFile front,@RequestParam("back") MultipartFile back) throws ServletException, IOException
{
	int f=0;
	System.out.println("Name session: "+uname);
	User ur = docuSrv.getReceiveremail(uname);

	byte[] img1Part= orgg.getBytes();
	System.out.println("byte: "+img1Part.length);
	
	byte[] img2 = front.getBytes();
	System.out.println("byte: "+img2.length);
	
	byte[] img3 = back.getBytes();
	System.out.println("byte: "+img3.length);
	
	System.out.println("did:"+di.getDocType()+" uid "+ur.getUid());
	
	IMG m = new IMG();
	m.setImg1(img1Part);
	m.setD(di);
	
	
	IMG im = new IMG();
	im.setImg1(img2);
	im.setD(di);
	
	
	IMG im2 = new IMG();
	im2.setImg1(img3);
	im2.setD(di);
	
	
	Set<IMG> sm = new  HashSet<IMG>();
	sm.add(im);
	sm.add(im2);
	sm.add(m);
	
	di.setIg(sm);
	System.out.println("User: "+ur.getUid());
	di.setU(ur);
	di.setDate("2019-12-12");
	
	f=docuSrv.addDocImg(di);
	ModelAndView mv = new ModelAndView();
	if(f==1)
	{
		mv.setViewName("successAdd");
		
	}
	else
		mv.setViewName("upLoadIMG");
	return mv;
}

@RequestMapping("/userRegisServ")
public ModelAndView addUser(@ModelAttribute("User") User u, @ModelAttribute("Address") Address d)
{
	u.setAddr(d);
	System.out.println("in user "+u.getAddr().getCity()+" " +u.getAddr().getCountry());
	
	docuSrv.regUser(u);
	
	ModelAndView mv = new ModelAndView();
	mv.setViewName("login");
	return mv;
}
@RequestMapping("/viewDocImgServ")
public ModelAndView viewSrchImg(HttpServletResponse response, @RequestParam("search") String search) 
{
	
	System.out.println("docImg type: "+search);
	List<DocIMG> doc = docuSrv.getDocId(search);
	ModelAndView mv = new ModelAndView();
	mv.addObject("doc", doc);
	mv.setViewName("viewSearchDoc");
	return mv;
}

@RequestMapping("/getIMG/{docid}")
public void showIMG(HttpServletResponse response, @PathVariable("docid") int docid) throws IOException
{
	response.setContentType("image/jpeg");
	IMG mg = docuSrv.getImgid(docid);
	byte[] b= mg.getImg1();
    InputStream in1 = new ByteArrayInputStream(b);
	IOUtils.copy(in1, response.getOutputStream()); 
}

@RequestMapping("/viewIMGs/{docid}")
public ModelAndView viewIMGs(HttpServletResponse response, HttpSession session, @PathVariable("docid") int docid) 
{
	System.out.println("Document ID: "+docid);
	session.setAttribute("docid", docid);
	List<IMG> dd =docuSrv.getallimgs(docid);
	System.out.println(dd.size());
	ModelAndView mv = new ModelAndView();
	mv.addObject("dd", dd);
	mv.setViewName("viewImages");
	return mv;
}

@RequestMapping("/getAllIMG/{imgId}/{docid}")
public void showAllIMG(HttpServletResponse response,HttpServletRequest request ,@PathVariable("imgId") int imgId, @PathVariable("docid") int docid) throws IOException
{
	response.setContentType("image/jpeg");
	  

	System.out.println("img id: " +imgId+"docId: "+docid);
	IMG mg = docuSrv.getImgs(imgId);
	byte[] b= mg.getImg1();
	InputStream in1 = new ByteArrayInputStream(b);
	IOUtils.copy(in1, response.getOutputStream()); 
}

@RequestMapping("/userLoginServ2")
public ModelAndView userLogin(@ModelAttribute("User") User u,HttpSession session)
{
	int f=0;
	System.out.println("Name: "+u.getName());
	f=docuSrv.checkUser(u);
	System.out.println(f);
	ModelAndView mv = new ModelAndView();
	//mv.addObject("dd", dd);
	if(f==1)
	{
		mv.setViewName("PayInfo");
		session.setAttribute("uname", u.getName());
	}
	else
		mv.setViewName("loginToPay");
	return mv;
}
@RequestMapping("/userRegisServ2")
public ModelAndView Userreg(@ModelAttribute("User") User u, @ModelAttribute("Address") Address d)
{
	u.setAddr(d);
	System.out.println("in user "+u.getAddr().getCity()+" " +u.getAddr().getCountry());
	
	docuSrv.regUser(u);
	
	ModelAndView mv = new ModelAndView();
	mv.setViewName("loginToPay");
	return mv;
}
@RequestMapping("/getAmount/{docid}")
public ModelAndView getAmount(@PathVariable("docid") int docid) {
	
	System.out.println("doc id: " +docid);
	DocIMG dm = docuSrv.getDocDetails(docid);
	DocuCost dc=docuSrv.getdocuCost(dm);
	ModelAndView mv = new ModelAndView();
	mv.addObject("dc",dc);
	mv.setViewName("PayInfo");

	return mv;
	
}
@RequestMapping("/tosendMail/{docid}/{uname}")
public ModelAndView tosendMail(@PathVariable("docid") int docid, @PathVariable("uname") String uname) {
	System.out.println("In mail controller");
	System.out.println("Name of receiver: " +uname);
	User ur = docuSrv.getReceiveremail(uname);
	
	DocIMG ud = docuSrv.getDocDetails(docid);
	User u = docuSrv.getUserDetails(ud);
	System.out.println("uemailk: " +u.getEmail());
	LocalDate myObj = LocalDate.now();
	System.out.println("Current Date: "+myObj);
	//to add receiver id and sender id and docu in DB
	recordSenderRec rc = new recordSenderRec();
	rc.setRid(ur.getUid());
	rc.setSid(u.getUid());
	rc.setDocid(docid);
	rc.setStatus("pending");
	rc.setDate(myObj);
	docuSrv.saveRecord(rc);
	
	SendMail.send(u.getEmail(), "REquest For Document", "emailToOneWho uploaded Document", "serverbusapp@gmail.com", "busapp123");
	
	SendMail.send(ur.getEmail(), "paymentSuccess","CarrierAddress:"+ur.getAddr().getCity(), "serverbusapp@gmail.com", "busapp123");
	
	ModelAndView mv = new ModelAndView();
	
	mv.setViewName("detailsTopicDoc");
	return mv;
}
}
