package com.docu.services;

import java.util.List;

import com.docu.model.DocIMG;
import com.docu.model.DocuCost;
import com.docu.model.IMG;
import com.docu.model.User;
import com.docu.model.recordSenderRec;

public interface docuServicesIntrf {

void regUser(User uu);
	
	int checkUser(User u);
	
	void insertImg(DocIMG di);
	
	List<DocIMG> viewallimgs();
	
	IMG getImgid(int docid);
	
	int getuserID(String name);
	
	void saveImg(IMG ig);

	List<DocIMG> getDocId(String search);
	
	List<IMG> getallimgs(int docid);

	IMG getImgs(int imid);

	DocIMG getDocDetails(int docid);

	DocuCost getdocuCost(DocIMG dm);

	User getUserDetails(DocIMG ud);

	User getReceiveremail(String uname);

	int addDocImg(DocIMG di);

	void saveRecord(recordSenderRec rc);

	recordSenderRec getStatusForSender(User ur);

	User getReceiverID(recordSenderRec rec);

	recordSenderRec getrecordDetails(int uid);

}
