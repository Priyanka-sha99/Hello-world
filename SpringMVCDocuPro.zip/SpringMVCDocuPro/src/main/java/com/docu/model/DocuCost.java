package com.docu.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class DocuCost {

	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	int cid;
	
	@Column
	String docType;

	@Column
	int docCost;

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public int getDocCost() {
		return docCost;
	}

	public void setDocCost(int docCost) {
		this.docCost = docCost;
	}
	
	
	
	
}
