package com.docu.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.docu.dao.docuOpdaoIntrf;
import com.docu.model.DocIMG;
import com.docu.model.DocuCost;
import com.docu.model.IMG;
import com.docu.model.User;
import com.docu.model.recordSenderRec;

public class docuServices implements docuServicesIntrf{
@Autowired
docuOpdaoIntrf docuOp;
	public void regUser(User uu) {
		docuOp.regUser(uu);
		
	}

	public int checkUser(User u) {
		
		return docuOp.checkUser(u);
	}

	public void insertImg(DocIMG di) {
		
		docuOp.insertImg(di);
		
	}

	public List<DocIMG> viewallimgs() {
		
		return docuOp.viewallimgs();
	}

	public IMG getImgid(int docid) {
		
		return docuOp.getImgid(docid);
	}

	public int getuserID(String name) {
		
		return docuOp.getuserID(name);
	}

	public void saveImg(IMG ig) {
		docuOp.saveImg(ig);
		
	}

	public List<DocIMG> getDocId(String search) {
		// TODO Auto-generated method stub
		return docuOp.getDocId(search);
	}

	public List<IMG> getallimgs(int docid) {
		// TODO Auto-generated method stub
		return docuOp.getallimgs(docid);
	}

	public IMG getImgs(int imid) {
		// TODO Auto-generated method stub
		return docuOp.getImgs(imid);
	}

	public DocIMG getDocDetails(int docid) {
		// TODO Auto-generated method stub
		return docuOp.getDocDetails(docid);
	}

	public DocuCost getdocuCost(DocIMG dm) {
		// TODO Auto-generated method stub
		return docuOp.getdocuCost(dm);
	}

	public User getUserDetails(DocIMG ud) {
		// TODO Auto-generated method stub
		return docuOp.getUserDetails(ud);
	}

	public User getReceiveremail(String uname) {
		// TODO Auto-generated method stub
		return docuOp.getReceiveremail(uname);
	}

	public int addDocImg(DocIMG di) {
		// TODO Auto-generated method stub
		return docuOp.addDocImg(di);
	}

	public void saveRecord(recordSenderRec rc) {
		docuOp.saveRecord(rc);
		
	}

	public recordSenderRec getStatusForSender(User ur) {
		// TODO Auto-generated method stub
		return docuOp.getStatusForSender(ur);
	}

	public User getReceiverID(recordSenderRec rec) {
		// TODO Auto-generated method stub
		return docuOp.getReceiverID(rec);
	}

	public recordSenderRec getrecordDetails(int uid) {
		// TODO Auto-generated method stub
		return docuOp.getrecordDetails(uid);
	}

}
