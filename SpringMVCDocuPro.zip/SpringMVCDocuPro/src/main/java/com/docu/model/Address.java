package com.docu.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;




	@Entity
	@Table
	public class Address {
		@Id
		@GeneratedValue(strategy=GenerationType.IDENTITY)
		int aid;
		@Column
		String city;
		@Column
		String state;
		@Column
		String country;
		
		
		public int getId() {
			return aid;
		}
		public void setId(int id) {
			this.aid = id;
		}
		
		public String getCity() {
			return city;
		}
		public void setCity(String city) {
			this.city = city;
		}
		public String getState() {
			return state;
		}
		public void setState(String state) {
			this.state = state;
		}
		public String getCountry() {
			return country;
		}
		public void setCountry(String country) {
			this.country = country;
		}
		
}
