package com.docu.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.docu.model.DocIMG;
import com.docu.model.DocuCost;
import com.docu.model.IMG;
import com.docu.model.User;
import com.docu.model.recordSenderRec;
@Transactional
public class docuOpdao implements docuOpdaoIntrf {
	@Autowired
	private SessionFactory sessionFactory;
	
			//register user
	public void regUser(User uu) {
		Session session = sessionFactory.getCurrentSession();
		session.persist(uu);
		
	}

	public int checkUser(User u) {
		String hql = " from User where name='"+u.getName()+"' and password='"+u.getPassword()+"' ";
		Query q = sessionFactory.getCurrentSession().createQuery(hql);
		if(q.list().size()>0)
			return 1;
		else
			return 0;
	}

	public void insertImg(DocIMG di) {
		// TODO Auto-generated method stub
		
	}

	public List<DocIMG> viewallimgs() {
		// TODO Auto-generated method stub
		return null;
	}

	public IMG getImgid(int docid) {
		String hql = " from IMG where d_docid="+docid+" ";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		return (IMG) query.list().get(0);
	}

	public int getuserID(String name) {
		// TODO Auto-generated method stub
		return 0;
	}

	public void saveImg(IMG ig) {
		Session session = sessionFactory.getCurrentSession();
		session.persist(ig);
		
	}
	
	/**************** 	TO GET DOC-ID FROM DOCIMG TABLE   **************************/

	public List<DocIMG> getDocId(String search) {
		String hql = " from DocIMG where docType='"+search+"' ";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		return query.list();
	}
	
	/**************** 	TO GET ALL IMAGES FROM IMG TABLE   **************************/

	public List<IMG> getallimgs(int docid) {
		String hql = " from IMG where d="+docid+" ";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		return query.list();
	}

	public IMG getImgs(int imid) {
		String hql = " from IMG where imgId="+imid+" ";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		return (IMG) query.list().get(0);
	}

	public DocIMG getDocDetails(int docid) {
		String hql = " from DocIMG where docid="+docid+" ";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		return (DocIMG) query.list().get(0);
	}

	public DocuCost getdocuCost(DocIMG dm) {
		String hql = " from DocuCost where docType='"+dm.getDocType()+"' ";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		return (DocuCost) query.list().get(0);
		
	}

	public User getUserDetails(DocIMG ud) {
		String hql = " from User where uid="+ud.getU().getUid()+" ";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		return (User) query.list().get(0);
	}

	public User getReceiveremail(String uname) {
		String hql = " from User where name='"+uname+"' ";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		return (User) query.list().get(0);
	}

	public int addDocImg(DocIMG di) {
		Session session = sessionFactory.getCurrentSession();
		session.persist(di);
		return 1;
		
	}

	public void saveRecord(recordSenderRec rc) {
		Session session = sessionFactory.getCurrentSession();
		session.persist(rc);
		
	}

	public recordSenderRec getStatusForSender(User ur) {
		String hql = " from recordSenderRec where sid="+ur.getUid()+"  ";
		Query q = sessionFactory.getCurrentSession().createQuery(hql);
		if(q.list().size()>0)
				return (recordSenderRec) q.list().get(0);
		else 
			return null;
	
	}

	public User getReceiverID(recordSenderRec rec) {
		String hql = " from User where uid="+rec.getRid()+" ";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		return (User) query.list().get(0);
	}

	public recordSenderRec getrecordDetails(int uid) {
		String hql = " from recordSenderRec where sid="+uid+" or rid="+uid+" ";
		Query q = sessionFactory.getCurrentSession().createQuery(hql);
		return (recordSenderRec) q.list().get(0);
	}

}
