package com.docu.model;


import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table
public class DocIMG{
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
@Column
int docid;
	
@Column
String docType;

@Column
long docNum;

@Column
String area;

@Column
String date;

@OneToMany(cascade=CascadeType.ALL) 

Set<IMG> ig;

@OneToOne 

User u;



public String getDate() {
	return date;
}

public void setDate(String date) {
	this.date = date;
}

public String getArea() {
	return area;
}

public void setArea(String area) {
	this.area = area;
}

public User getU() {
	return u;
}

public void setU(User u) {
	this.u = u;
}



public Set<IMG> getIg() {
	return ig;
}

public void setIg(Set<IMG> ig) {
	this.ig = ig;
}

public String getDocType() {
	return docType;
}

public void setDocType(String docType) {
	this.docType = docType;
}



public int getDocid() {
	return docid;
}

public void setDocid(int docid) {
	this.docid = docid;
}

public long getDocNum() {
	return docNum;
}

public void setDocNum(long docNum) {
	this.docNum = docNum;
}




}
